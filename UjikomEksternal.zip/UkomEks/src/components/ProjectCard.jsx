import React from "react";

const FormatDescription = (description) => {
  return description.substring(0, 50) + "...";
};

const ProjectCard = (props) => {
  const { project } = props;

  const handleBuyClick = () => {
    alert("Makanan telah dibeli, Terima kasih & Selamat Menikmati.");
  };

  return (
    <div className="card">
      <img className="fotomenu" src={project.strCategoryThumb} alt={project.strCategory} />
      <section className="section_light">
        <h5 className="strong">
          <strong>{project.strCategory}</strong>
        </h5>
        <p>{FormatDescription(project.strCategoryDescription)}</p>
        <button className="buttonedit" onClick={handleBuyClick}>
          Buy
        </button>
      </section>
    </div>
  );
};

export default ProjectCard;
