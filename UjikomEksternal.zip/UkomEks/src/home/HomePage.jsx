import React from "react";
import "./homepage.css";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const HomePage = () => {
  const settings = {
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
  };

  return (
    <div>
      <div className="slider-container">
        <Slider {...settings}>
          <div>
            <img src="/Kickstart1.jpg" alt="" className="slider-image" />
          </div>
          <div>
            <img src="/Kickstart2.jpg" alt="" className="slider-image" />
          </div>
          <div>
            <img src="/Kickstart3.jpg" alt="" className="slider-image" />
          </div>
        </Slider>
      </div>

      <h1 className="judul">Tentang Kami</h1>
      <div className="content-2">
        <p>
          Kickstart Cafe selalu menjadi visi yang dimiliki oleh pendiri Jamie
          dan Ray. Ide tersebut selalu ada di antara mereka dan terus berkembang
          selama bertahun-tahun. Tumbuh besar di dunia sepeda motor, mereka
          berdua mengembangkan minat terhadap sepeda motor antik. Mereka
          menyadari bahwa generasi pengendara baru ini membutuhkan tempat di
          mana semua orang dapat bertemu. Tempat di mana Anda dapat bertemu
          teman baru untuk diajak berkendara, berbincang tentang bangunan
          terbaru, atau bahkan berbagi karya seni dan musik. Ini awalnya dimulai
          dengan halaman media sosial yang berkembang (518 Sepeda Motor).
          Melalui perjalanan di media sosial ini mereka menemukan Mike Milliron. dan dengan persahabatan ini muncullah
          kecintaan terhadap kopi. Kami melihat potensi yang bisa diberikan oleh
          kedai kopi kepada masyarakat. Kopi dan Sepeda Motor memiliki banyak
          kesamaan nilai-nilai fundamental, setiap orang mempunyai selera dan
          gayanya masing-masing, namun kedua hal ini menyatukan semua orang.
        </p>
        <br/>
        <br/>
        <p>Menu!!</p>
        <a href="./projects">
          <button className="button-home">Daftar Menu</button>
        </a>
      </div>

      {/* Footer */}
      <div className="footer">
        <div className="alamat">
          <p>LOKASI</p>
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.382878812559!2d106.71337411089085!3d-6.344436662046593!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69e5826ce42495%3A0x789675f59627dd20!2sLetris%20Indonesia%20Smk%202%2C%20Pd.%20Benda%2C%20Kec.%20Pamulang%2C%20Kota%20Tangerang%20Selatan%2C%20Banten!5e0!3m2!1sid!2sid!4v1709532398922!5m2!1sid!2sid"
            width="400"
            height="250"
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          ></iframe>
        </div>
        <div className="link">
          <p>LINK</p>
          <p className="link-video">
            <a
              href="https://www.youtube.com/watch?feature=shared&v=fa231XK8NAo"
              target="_blank"
            >
              Contoh video Presentasi
            </a>
          </p>
          <p className="link-video">
            <a href="https://www.youtube.com/@pal8189" target="_blank">
              Link Youtube
            </a>
          </p>
        </div>
        <div className="contact-us">
          <p>CONTACT US</p>
          <h2>0213456789</h2>
          <p>ALAMAT</p>
          <h2>
            Jl. Raya Siliwangi No.55, Pondok Benda, Tangerang Selatan, Banten
          </h2>
          <p>NOMOR WHATSAPP</p>
          <h2>0878-1234-4321</h2>
        </div>
      </div>
      <div className="sub-footer">
        <p>© Made with patience by Muhammad Nauval Aqiilah</p>
      </div>
    </div>
  );
};

export default HomePage;
